package com.example.billCalculator.Entity;


public class Consumer {
	private int consumerId;
	private String consumeName;
	private String city;
	private String area;
	//@Enumerated(EnumType.STRING)
//	@Column(name = "status")
	private ConsumerType type;
	

}
