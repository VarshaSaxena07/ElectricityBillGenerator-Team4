package com.example.billCalculator.Entity;

public enum ConsumerType {
	    DOMESTIC,COMMERCIAL
	}
