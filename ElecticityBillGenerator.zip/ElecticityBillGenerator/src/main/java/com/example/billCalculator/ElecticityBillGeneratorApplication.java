package com.example.billCalculator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElecticityBillGeneratorApplication {

	public static void main(String[] args) {
		System.out.println("Hii");
		SpringApplication.run(ElecticityBillGeneratorApplication.class, args);
	}

}
